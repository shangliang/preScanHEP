PyMultiNest tutorial
=======================

Download or clone this project to your disk.
Start the tutorial at http://johannesbuchner.github.io/pymultinest-tutorial/ !


