'''
    we define the problem: we need a prior function which maps from [0:1] to the parameter space [0:2]
    we only have one parameter, the position of the gaussian (ndim == 1)
    Map it from the unity interval 0:1 to our problem space 0:2 under a uniform prior
'''
import numpy
from numpy import log, exp, pi
import pymultinest

def prior(cube, ndim, nparams):
	cube[0] = cube[0] * 2

def loglike(cube, ndim, nparams):
	# get the current parameter (is between 0:2 now)
	pos = cube[0]
	likelihood = exp(-0.5 * ((pos - positions)/width) ** 2)/(2 * pi * width ** 2) ** 0.5
	return log(likelihood.mean())

# parameters
positions = numpy.array([0.1, 0.2, 0.5, 0.55, 0.9, 1.1])
width = 0.01
parameters = ["position"]
n_params = len(parameters)

# run MultiNest
pymultinest.run(loglike, prior, n_params, outputfiles_basename = 'out/', 
	resume = False, verbose = True, n_live_points = 1000)



